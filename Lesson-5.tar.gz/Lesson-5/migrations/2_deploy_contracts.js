var ownableLib = artifacts.require("./Ownable.sol");
var safemathLib = artifacts.require("./SafeMath.sol");
var PayRoll = artifacts.require("./Payroll.sol");

module.exports = function(deployer) {
  deployer.deploy(ownableLib);
  deployer.link(ownableLib, PayRoll);
  deployer.deploy(safemathLib);
  deployer.link(safemathLib, PayRoll);
  deployer.deploy(PayRoll);
};
